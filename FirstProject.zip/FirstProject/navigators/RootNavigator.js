import { StyleSheet,View} from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LittleLemonWelcome from "../components/LittleLemonWelcome";
import LittleLemonSubscribe from "../components/LittleLemonSubscribe";

const Stack = createNativeStackNavigator();

export default function RootNavigator()
{
    return (
        <View style={styles.container}>
            <View style={{flex:1}}>
                <Stack.Navigator screenOptions={{ headerStyle:  { backgroundColor: 'white', },headerTitleStyle:{fontWeight: 'bold',fontSize: 20}}}>
                    <Stack.Screen name="Welcome" component={LittleLemonWelcome} />
                    <Stack.Screen name="Subscribe" component={LittleLemonSubscribe} />
                </Stack.Navigator>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex:1,
        justifyContent: 'space-between',
    }
})