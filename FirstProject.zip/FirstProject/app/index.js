import RootNavigator from "../navigators/RootNavigator";

export default function HomeScreen() {

    return (
        <RootNavigator/>
    );

}

