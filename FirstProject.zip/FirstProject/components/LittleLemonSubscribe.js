import {View, Text, Image, StyleSheet, Pressable, TextInput, Alert} from 'react-native';
import {useState} from "react";

export default function LittleLemonSubscribe()
{
    const [email,setEmail] = useState('');
    const validateEmail = (email) => {
        return email.match(
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
    };

    return (
        <View style={styles.container}>
            <View style={styles.mainText}>
                <Image style={styles.image} resizeMode={'contain'} source={require('../assets/images/little-lemon-logo-grey.png')} />
                <Text style={styles.content}>Subscribe to our newsletter for our latest delicious recipes!</Text>
                <TextInput style={styles.input} placeholder={"Type Your Email"} value={email} placeholderTextColor={'gray'} onChangeText={setEmail}/>
                <Pressable
                    style={({pressed})=> [{borderRadius:10},!validateEmail(email) ? {backgroundColor:'gray'} : {backgroundColor:'#3e524b'},pressed && {opacity:0.7} ]}
                    onPress={() => {
                        Alert.alert("Thanks for subscribing, stay tuned!");
                        setEmail("");
                        }
                    }
                    disabled={!validateEmail(email)}
                >
                    <Text style={styles.button}>Subscribe</Text>
                </Pressable>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        borderTopWidth: 1,
        borderColor: '#D3D3D3'
    },
    image: {
        width: 100,
        height: 100,
    },
    content: {
        fontSize:20,
        textAlign:'center',
        fontWeight:'600',
        color:'#3e524b'
    },
    input: {
        width:320,
        height:40,
        padding:10,
        borderWidth:1,
        borderColor:'#3e524b',
        borderRadius:10,
        fontSize:16
    },
    button: {
        textAlign:'center',
        padding:10,
        width:320,
        height:40,
        color:'white',
        fontSize:20,
        fontWeight:'bold',
    },
    mainText: {
        display:'flex',
        flex:0.6,
        justifyContent:'space-evenly',
        alignItems:'center',
        margin:30,
    }
});