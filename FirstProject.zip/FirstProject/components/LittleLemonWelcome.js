import {View, Text, Image, StyleSheet, Pressable} from 'react-native';

export default function LittleLemonWelcome({navigation})
{
    return (
        <View style={styles.container}>
            <View style={styles.mainText}>
                <Image style={styles.img} resizeMode={'contain'} source={require('../assets/images/little-lemon-logo.png')} />
                <Text style={styles.content}>Little Lemon, your local Mediterranean Bistro</Text>
            </View>
            <Pressable onPress={ () => navigation.navigate('Subscribe') }>
                <Text style={styles.button}>NewsLetter</Text>
            </Pressable>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex:1,
        justifyContent:'space-evenly',
        alignItems:'center',
        backgroundColor:'white',
        borderTopWidth:1,
        borderColor:'#D3D3D3',
    },
    mainText: {
        display:'flex',
        flex:0.45,
        width:'60%',
        alignItems:'center',
        justifyContent:'space-between',
    },
    img: {
        width: 200,
        height: 200,
    },
    content: {
        fontSize:20,
        textAlign:'center',
        fontWeight:'bold',
    },
    button: {
        backgroundColor:'#3e524b',
        paddingVertical:10,
        paddingHorizontal:120,
        color:'white',
        borderRadius:10,
        fontSize:20,
        fontWeight:'bold',
    }
})